<?php
require 'header.php';

echo '<h1> сейчас мы на ' . basename(__FILE__);